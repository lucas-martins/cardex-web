import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Toaster } from "react-hot-toast";

import App from "./App.tsx";
import "./index.css";
import { AuthProvider } from "./context/AuthProvider";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>

    <Toaster
      position="top-right"
      toastOptions={{
        duration: 3500,
      }}
    />
  </StrictMode>,
);
