import { apiClient } from "../api/apiClient";
import type { Card, CardCondition, CardLanguage } from "../../types/card";
import type { PageResponse } from "../../types/page";
import type { CollectionSummary } from "../../types/collectionSummary";
import type { CollectionAnalytics } from "../../types/collectionAnalytics";
import type { CollectionGoals } from "../../types/collectionGoals";
import type { CollectionProgress } from "../../types/collectionProgress";
import type { CollectionDetails } from "../../types/collectionDetails";
import type {
  CardImportPreview,
  CardImportResult,
} from "../../types/cardImport";
import type { CollectionChecklist } from "../../types/collectionChecklist";

export interface FindCardsParams {
  page?: number;
  size?: number;
  name?: string;
  number?: string;
  collection?: string;
  rarity?: string;
  language?: CardLanguage;
  condition?: CardCondition;
  favorite?: boolean;
  sort?: string;
}

export interface CreateCardRequest {
  externalId: string;
  quantity: number;
  language: CardLanguage;
  condition: CardCondition;
  notes?: string;
}

export interface UpdateCardRequest {
  quantity: number;
  language: CardLanguage;
  condition: CardCondition;
  notes?: string;
}

export interface UpdateFavoriteRequest {
  favorite: boolean;
}

export async function findCards(
  params: FindCardsParams = {},
): Promise<PageResponse<Card>> {
  const response = await apiClient.get<PageResponse<Card>>("/cards", {
    params: {
      page: params.page ?? 0,
      size: params.size ?? 20,
      name: params.name || undefined,
      number: params.number || undefined,
      collection: params.collection || undefined,
      rarity: params.rarity || undefined,
      language: params.language || undefined,
      condition: params.condition || undefined,
      favorite: params.favorite,
      sort: params.sort || undefined,
    },
  });

  return response.data;
}

export async function createCard(request: CreateCardRequest): Promise<Card> {
  const response = await apiClient.post<Card>("/cards", request);

  return response.data;
}

export async function deleteCard(id: number): Promise<void> {
  await apiClient.delete(`/cards/${id}`);
}

export async function updateCard(
  id: number,
  request: UpdateCardRequest,
): Promise<Card> {
  const response = await apiClient.put<Card>(`/cards/${id}`, request);

  return response.data;
}

export async function getCollectionSummary(): Promise<CollectionSummary> {
  const response = await apiClient.get<CollectionSummary>("/cards/summary");

  return response.data;
}

export async function updateFavorite(
  id: number,
  request: UpdateFavoriteRequest,
): Promise<Card> {
  const response = await apiClient.patch<Card>(
    `/cards/${id}/favorite`,
    request,
  );

  return response.data;
}

export async function findCardById(id: number): Promise<Card> {
  const response = await apiClient.get<Card>(`/cards/${id}`);

  return response.data;
}

export async function getCollectionAnalytics(): Promise<CollectionAnalytics> {
  const response = await apiClient.get<CollectionAnalytics>("/cards/analytics");

  return response.data;
}

export async function getCollectionGoals(): Promise<CollectionGoals> {
  const response = await apiClient.get<CollectionGoals>("/cards/goals");

  return response.data;
}

export async function getCollectionProgress(): Promise<CollectionProgress[]> {
  const response = await apiClient.get<CollectionProgress[]>(
    "/cards/collection-progress",
  );

  return response.data;
}

export async function getCollectionDetails(
  collectionId: string,
): Promise<CollectionDetails> {
  const response = await apiClient.get<CollectionDetails>(
    `/cards/collections/${collectionId}`,
  );

  return response.data;
}

export async function exportCollectionCsv(): Promise<Blob> {
  const response = await apiClient.get<Blob>("/cards/export/csv", {
    responseType: "blob",
  });

  return response.data;
}

export async function previewCollectionCsv(
  file: File,
): Promise<CardImportPreview> {
  const formData = new FormData();

  formData.append("file", file);

  const response = await apiClient.post<CardImportPreview>(
    "/cards/import/csv/preview",
    formData,
  );

  return response.data;
}

export async function importCollectionCsv(
  file: File,
): Promise<CardImportResult> {
  const formData = new FormData();

  formData.append("file", file);

  const response = await apiClient.post<CardImportResult>(
    "/cards/import/csv",
    formData,
  );

  return response.data;
}

const collectionChecklistRequests = new Map<
  string,
  Promise<CollectionChecklist>
>();

export function getCollectionChecklist(
  collectionId: string,
): Promise<CollectionChecklist> {
  const existingRequest = collectionChecklistRequests.get(collectionId);

  if (existingRequest) {
    return existingRequest;
  }

  const request = apiClient
    .get<CollectionChecklist>(`/cards/collections/${collectionId}/checklist`, {
      timeout: 30000,
    })
    .then((response) => response.data)
    .finally(() => {
      collectionChecklistRequests.delete(collectionId);
    });

  collectionChecklistRequests.set(collectionId, request);

  return request;
}
